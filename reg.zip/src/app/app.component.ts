import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'RegForm';

  myName: string = "";
  updateName(input: string) {
      this.myName = input;
  }

  email: string = "";
  updateEmail(input: string) {
    console.log(input);
      this.email = input;
      console.log(this.email);
  }
}
